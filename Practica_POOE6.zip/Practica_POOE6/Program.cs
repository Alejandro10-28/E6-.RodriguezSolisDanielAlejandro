﻿using System;

namespace Practica_POOE6
{
    class Program
    {
        static void Main(string[] args)
        {
            Principal principal=new Principal();
            principal.Bienvenida();
        }
    }
}
