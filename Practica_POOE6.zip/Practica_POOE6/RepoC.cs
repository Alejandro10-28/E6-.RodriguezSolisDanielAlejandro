using System;

namespace Practica_POOE6
{
  public class RepoC
  {
    public double cm { get; set; }
    public double Me { get; set; }
    public double lt { get; set; }
        
  }
}
